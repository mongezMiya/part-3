const searchInput = document.getElementById("searchInput");

if (searchInput) {

    searchInput.addEventListener("keyup", function() {

        let filter = searchInput.value.toLowerCase();

        let ministries =
            document.querySelectorAll("#ministryList li");

        ministries.forEach(function(ministry) {

            let text =
                ministry.textContent.toLowerCase();

            if (text.includes(filter)) {

                ministry.style.display = "";

            } else {

                ministry.style.display = "none";

            }

        });

    });

}