const enquiryForm = document.getElementById("enquiryForm");

if (enquiryForm) {

    enquiryForm.addEventListener("submit", function (event) {

        event.preventDefault();

        let fullname = document.getElementById("fullname").value;
        let email = document.getElementById("email").value;
        let phone = document.getElementById("phone").value;
        let enquiryType = document.getElementById("enquiryType").value;

        if (
            fullname === "" ||
            email === "" ||
            phone === "" ||
            enquiryType === ""
        ) {

            document.getElementById("enquiryMessage").innerHTML =
                "Please complete all fields.";

            return;
        }

        document.getElementById("enquiryMessage").innerHTML =
            "Thank you for contacting Saved Church UD-OLGC. We will contact you shortly.";

    });

}