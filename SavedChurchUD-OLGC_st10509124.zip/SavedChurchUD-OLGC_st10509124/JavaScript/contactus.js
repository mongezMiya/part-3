const contactForm = document.getElementById("contactForm");

if (contactForm) {

    contactForm.addEventListener("submit", function(event) {

        event.preventDefault();

        let name = document.getElementById("contactName").value;
        let email = document.getElementById("contactEmail").value;
        let type = document.getElementById("messageType").value;
        let message = document.getElementById("message").value;

        if (
            name === "" ||
            email === "" ||
            type === "" ||
            message === ""
        ) {

            document.getElementById("contactMessage").innerHTML =
                "Please complete all fields before submitting.";

            return;
        }

        document.getElementById("contactMessage").innerHTML =
            "Thank you. Your message has been received by Saved Church UD-OLGC.";

    });

}